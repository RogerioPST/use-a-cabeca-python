function Ovni(context, imagem, imgExplosao, invertido) {
   this.context = context;
   this.imagem = imagem;
   this.x = 0;
   this.y = 0;
   this.velocidade = 0;
   this.imgExplosao = imgExplosao;
   this.invertido = invertido;
}
Ovni.prototype = {
   atualizar: function() {
      this.x -= 
         this.velocidade * this.animacao.decorrido / 1000;      
         //console.log('pos aviao: ' + this.x);
      if (this.x + this.imagem.width < 0) {
         this.animacao.excluirSprite(this);
         this.colisor.excluirSprite(this);
      }
   },
   desenhar: function() {
      var ctx = this.context;
      var img = this.imagem;
      ctx.drawImage(img, this.x, this.y, img.width, img.height);      
   },
   retangulosColisao: function() {
      // Estes valores vão sendo ajustados aos poucos
      
      if (!this.invertido){         
         // obstaculoCima
      var rets = 
      [ 
         {x: this.x+60, y: this.y+218, largura: 10, altura: 20},
         {x: this.x+56, y: this.y+187, largura: 16, altura: 30},
         {x: this.x+52, y: this.y+146, largura: 22, altura: 40},
      ];
   }
   else{      
      //obstaculoBaixo
      var rets = 
      [ 
         {x: this.x+60, y: this.y+1, largura: 10, altura: 20},
         {x: this.x+56, y: this.y+21, largura: 16, altura: 30},
         {x: this.x+52, y: this.y+51, largura: 22, altura: 40},
      ];
   }
      
      // Desenhando os retângulos para visualização
      
      var ctx = this.context;
      
      for (var i in rets) {
         ctx.save();
         ctx.strokeStyle = 'yellow';       
         ctx.strokeRect(rets[i].x, rets[i].y, rets[i].largura, 
                        rets[i].altura);         
         ctx.restore();
      }
      
      
      return rets;
   },
   colidiuCom: function(outro) {
      // Se colidiu com um Tiro, os dois desaparecem
      if (outro instanceof Tiro) {
         this.animacao.excluirSprite(this);
         this.colisor.excluirSprite(this);
         this.animacao.excluirSprite(outro);
         this.colisor.excluirSprite(outro);
         
         var explosao = new Explosao(this.context, this.imgExplosao, 
                                     this.x, this.y);
         this.animacao.novoSprite(explosao);
      }
   }
}
