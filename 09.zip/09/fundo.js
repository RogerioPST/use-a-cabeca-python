function Fundo(context, imagem) {
   this.context = context;
   this.imagem = imagem;
   this.velocidade = 0;
   this.posicaoEmenda = 0;
}
Fundo.prototype = {
   atualizar: function() {
      // Atualizar a posição de emenda
      this.posicaoEmenda -= 
         this.velocidade * this.animacao.decorrido / 1000;
      
      // Emenda passou da posição
      if (Math.abs(this.posicaoEmenda) > this.imagem.width)
         this.posicaoEmenda = 0;
   },
   desenhar: function() {
      var img = this.imagem;  // Para facilitar a escrita :D
      
      // Primeira cópia
      var posicaoX = this.posicaoEmenda + img.width;
      this.context.drawImage(img, posicaoX, canvas.height-img.height, img.width, img.height);
      
      // Segunda cópia
      posicaoX = this.posicaoEmenda;
      this.context.drawImage(img, posicaoX, canvas.height-img.height, img.width, img.height);     
   }
}

