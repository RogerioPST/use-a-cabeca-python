function Fundo(context, imagem,imgExplosao) {
   this.context = context;
   this.imagem = imagem;
   this.x = 0;
   this.y = 0;
   this.imgExplosao = imgExplosao;
   this.velocidade = 0;
   this.posicaoEmenda = 0;
   this.posicaoX = 0;
}
Fundo.prototype = {
   atualizar: function() {
      // Atualizar a posição de emenda
      this.posicaoEmenda -= 
         this.velocidade * this.animacao.decorrido / 1000;
      
      // Emenda passou da posição
      if (Math.abs(this.posicaoEmenda) > this.imagem.width)
         this.posicaoEmenda = 0;
   },
   desenhar: function() {
      var img = this.imagem;  // Para facilitar a escrita :D
      
      // Primeira cópia
      this.posicaoX = this.posicaoEmenda + img.width;
      this.context.drawImage(img, this.posicaoX, canvas.height-img.height, img.width, img.height);
      
      // Segunda cópia
      this.posicaoX = this.posicaoEmenda;
      this.context.drawImage(img, this.posicaoX, canvas.height-img.height, img.width, img.height);     
   },
   retangulosColisao: function() {
      // Estes valores vão sendo ajustados aos poucos
      console.log('pos x:' + this.posicaoX);
      var posFuturaX = this.posicaoEmenda;
      var posFutura2X = this.posicaoEmenda+this.imagem.width;
      var rets = 
      [ 
         {x: posFuturaX, y: this.y+445, largura: 35, altura: 10},
         {x: posFuturaX+36, y: this.y+454, largura: 60, altura: 10},
         {x: posFuturaX+97, y: this.y+452, largura: 5, altura: 10},
         {x: posFuturaX+105, y: this.y+450, largura: 5, altura: 10},
         {x: posFuturaX+111, y: this.y+449, largura: 5, altura: 10},
         {x: posFuturaX+117, y: this.y+448, largura: 5, altura: 10},
         {x: posFuturaX+123, y: this.y+447, largura: 5, altura: 10},
         {x: posFuturaX+129, y: this.y+445, largura: 5, altura: 10},
         {x: posFuturaX+135, y: this.y+440, largura: 5, altura: 10},
         {x: posFuturaX+141, y: this.y+432, largura: 5, altura: 10},
         {x: posFuturaX+147, y: this.y+425, largura: 5, altura: 10},
         {x: posFuturaX+153, y: this.y+417, largura: 100, altura: 10},
         {x: posFuturaX+254, y: this.y+419, largura: 5, altura: 10},
         {x: posFuturaX+260, y: this.y+421, largura: 5, altura: 10},
         {x: posFuturaX+266, y: this.y+423, largura: 5, altura: 10},
         {x: posFuturaX+272, y: this.y+425, largura: 5, altura: 10},
         {x: posFuturaX+278, y: this.y+427, largura: 5, altura: 10},
         {x: posFuturaX+284, y: this.y+429, largura: 5, altura: 10},
         {x: posFuturaX+290, y: this.y+431, largura: 5, altura: 10},
         {x: posFuturaX+296, y: this.y+434, largura: 5, altura: 10},
         {x: posFuturaX+302, y: this.y+436, largura: 5, altura: 10},
         {x: posFuturaX+308, y: this.y+436, largura: 40, altura: 10},
         {x: posFuturaX+349, y: this.y+434, largura: 5, altura: 10},
         {x: posFuturaX+355, y: this.y+432, largura: 5, altura: 10},
         {x: posFuturaX+361, y: this.y+429, largura: 5, altura: 10},
         {x: posFuturaX+367, y: this.y+426, largura: 5, altura: 10},
         {x: posFuturaX+373, y: this.y+422, largura: 64, altura: 10},
         {x: posFuturaX+438, y: this.y+426, largura: 5, altura: 10},
         {x: posFuturaX+443, y: this.y+430, largura: 5, altura: 10},
         {x: posFuturaX+449, y: this.y+436, largura: 5, altura: 10},
         {x: posFuturaX+455, y: this.y+442, largura: 5, altura: 10},
         {x: posFuturaX+461, y: this.y+448, largura: 5, altura: 10},
         {x: posFuturaX+467, y: this.y+454, largura: 5, altura: 10},
         {x: posFuturaX+473, y: this.y+454, largura: 40, altura: 10},
         {x: posFuturaX+514, y: this.y+456, largura: 5, altura: 10},
         {x: posFuturaX+520, y: this.y+458, largura: 5, altura: 10},
         {x: posFuturaX+526, y: this.y+460, largura: 5, altura: 10},
         {x: posFuturaX+532, y: this.y+464, largura: 38, altura: 10},
         {x: posFuturaX+571, y: this.y+462, largura: 5, altura: 10},
         {x: posFuturaX+577, y: this.y+458, largura: 5, altura: 10},
         {x: posFuturaX+583, y: this.y+453, largura: 5, altura: 10},
         {x: posFuturaX+589, y: this.y+446, largura: 5, altura: 10},
         {x: posFuturaX+595, y: this.y+439, largura: 5, altura: 10},
         {x: posFuturaX+601, y: this.y+436, largura: 36, altura: 10},
         {x: posFuturaX+638, y: this.y+432, largura: 5, altura: 10},
         {x: posFuturaX+644, y: this.y+427, largura: 5, altura: 10},
         {x: posFuturaX+650, y: this.y+421, largura: 5, altura: 10},
         {x: posFuturaX+656, y: this.y+415, largura: 5, altura: 10},
         {x: posFuturaX+662, y: this.y+413, largura: 81, altura: 10},
         {x: posFuturaX+744, y: this.y+417, largura: 5, altura: 10},
         {x: posFuturaX+750, y: this.y+421, largura: 5, altura: 10},
         {x: posFuturaX+756, y: this.y+429, largura: 5, altura: 10},
         {x: posFuturaX+762, y: this.y+435, largura: 5, altura: 10},
         {x: posFuturaX+768, y: this.y+437, largura: 5, altura: 10},
         {x: posFuturaX+774, y: this.y+439, largura: 5, altura: 10},
         {x: posFuturaX+780, y: this.y+441, largura: 5, altura: 10},
         {x: posFuturaX+786, y: this.y+443, largura: 5, altura: 10},
         {x: posFuturaX+792, y: this.y+445, largura: 8, altura: 10},



         {x: posFutura2X, y: this.y+445, largura: 35, altura: 10},
         {x: posFutura2X+36, y: this.y+454, largura: 60, altura: 10},
         {x: posFutura2X+97, y: this.y+452, largura: 5, altura: 10},
         {x: posFutura2X+105, y: this.y+450, largura: 5, altura: 10},
         {x: posFutura2X+111, y: this.y+449, largura: 5, altura: 10},
         {x: posFutura2X+117, y: this.y+448, largura: 5, altura: 10},
         {x: posFutura2X+123, y: this.y+447, largura: 5, altura: 10},
         {x: posFutura2X+129, y: this.y+445, largura: 5, altura: 10},
         {x: posFutura2X+135, y: this.y+440, largura: 5, altura: 10},
         {x: posFutura2X+141, y: this.y+432, largura: 5, altura: 10},
         {x: posFutura2X+147, y: this.y+425, largura: 5, altura: 10},
         {x: posFutura2X+153, y: this.y+417, largura: 100, altura: 10},
         {x: posFutura2X+254, y: this.y+419, largura: 5, altura: 10},
         {x: posFutura2X+260, y: this.y+421, largura: 5, altura: 10},
         {x: posFutura2X+266, y: this.y+423, largura: 5, altura: 10},
         {x: posFutura2X+272, y: this.y+425, largura: 5, altura: 10},
         {x: posFutura2X+278, y: this.y+427, largura: 5, altura: 10},
         {x: posFutura2X+284, y: this.y+429, largura: 5, altura: 10},
         {x: posFutura2X+290, y: this.y+431, largura: 5, altura: 10},
         {x: posFutura2X+296, y: this.y+434, largura: 5, altura: 10},
         {x: posFutura2X+302, y: this.y+436, largura: 5, altura: 10},
         {x: posFutura2X+308, y: this.y+436, largura: 40, altura: 10},
         {x: posFutura2X+349, y: this.y+434, largura: 5, altura: 10},
         {x: posFutura2X+355, y: this.y+432, largura: 5, altura: 10},
         {x: posFutura2X+361, y: this.y+429, largura: 5, altura: 10},
         {x: posFutura2X+367, y: this.y+426, largura: 5, altura: 10},
         {x: posFutura2X+373, y: this.y+422, largura: 64, altura: 10},
         {x: posFutura2X+438, y: this.y+426, largura: 5, altura: 10},
         {x: posFutura2X+443, y: this.y+430, largura: 5, altura: 10},
         {x: posFutura2X+449, y: this.y+436, largura: 5, altura: 10},
         {x: posFutura2X+455, y: this.y+442, largura: 5, altura: 10},
         {x: posFutura2X+461, y: this.y+448, largura: 5, altura: 10},
         {x: posFutura2X+467, y: this.y+454, largura: 5, altura: 10},
         {x: posFutura2X+473, y: this.y+454, largura: 40, altura: 10},
         {x: posFutura2X+514, y: this.y+456, largura: 5, altura: 10},
         {x: posFutura2X+520, y: this.y+458, largura: 5, altura: 10},
         {x: posFutura2X+526, y: this.y+460, largura: 5, altura: 10},
         {x: posFutura2X+532, y: this.y+464, largura: 38, altura: 10},
         {x: posFutura2X+571, y: this.y+462, largura: 5, altura: 10},
         {x: posFutura2X+577, y: this.y+458, largura: 5, altura: 10},
         {x: posFutura2X+583, y: this.y+453, largura: 5, altura: 10},
         {x: posFutura2X+589, y: this.y+446, largura: 5, altura: 10},
         {x: posFutura2X+595, y: this.y+439, largura: 5, altura: 10},
         {x: posFutura2X+601, y: this.y+436, largura: 36, altura: 10},
         {x: posFutura2X+638, y: this.y+432, largura: 5, altura: 10},
         {x: posFutura2X+644, y: this.y+427, largura: 5, altura: 10},
         {x: posFutura2X+650, y: this.y+421, largura: 5, altura: 10},
         {x: posFutura2X+656, y: this.y+415, largura: 5, altura: 10},
         {x: posFutura2X+662, y: this.y+413, largura: 81, altura: 10},
         {x: posFutura2X+744, y: this.y+417, largura: 5, altura: 10},
         {x: posFutura2X+750, y: this.y+421, largura: 5, altura: 10},
         {x: posFutura2X+756, y: this.y+429, largura: 5, altura: 10},
         {x: posFutura2X+762, y: this.y+435, largura: 5, altura: 10},
         {x: posFutura2X+768, y: this.y+437, largura: 5, altura: 10},
         {x: posFutura2X+774, y: this.y+439, largura: 5, altura: 10},
         {x: posFutura2X+780, y: this.y+441, largura: 5, altura: 10},
         {x: posFutura2X+786, y: this.y+443, largura: 5, altura: 10},
         {x: posFutura2X+792, y: this.y+445, largura: 8, altura: 10},
      ];
         
      // Desenhando os retângulos para visualização
      
      var ctx = this.context;
      
      for (var i in rets) {
         ctx.save();
         ctx.strokeStyle = 'yellow';       
         ctx.strokeRect(rets[i].x, rets[i].y, rets[i].largura, 
                        rets[i].altura);         
         ctx.restore();
      }
      
      
      return rets;
   },
   colidiuCom: function(outro) {
      // Se colidiu com um nave, a nave desaparece
      //if (outro instanceof Nave) {     
        // this.animacao.excluirSprite(outro);
         //this.colisor.excluirSprite(outro);
         
         //var explosao = new Explosao(this.context, this.imgExplosao, this.x, this.y);
         //this.animacao.novoSprite(explosao);                  
      //}
   }
}
       


