package br.gov.caixa.setbot.setbot;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

class DetectaConexao{
  //  private static final String TAG = DetectConnection.class.getSimpleName();
    public static boolean internetEstaDisponivel(Context context){
        NetworkInfo informacaoDaRede = (NetworkInfo) ((ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (informacaoDaRede == null){
            return false;
        }else{
            if(informacaoDaRede.isConnected()){
                return true;
            }else{
                return true;
            }

        }
    }
}
