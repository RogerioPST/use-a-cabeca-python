package br.gov.caixa.setbot.setbot;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

public class IbcActivity extends Activity {

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ibc);

        ImageView botaoAbreBot = (ImageView) findViewById(R.id.botaoAbreBot);
        botaoAbreBot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intencaoAbrirChatBot = new Intent(IbcActivity.this, MainActivity.class);
                startActivity(intencaoAbrirChatBot);

                // após chamar a activity do chatbot, fecha essa activity/tela
                finish();

            }
        });





    }

}
