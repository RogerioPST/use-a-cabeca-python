package br.gov.caixa.setbot.setbot;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;


import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    static boolean PERMITIR_JAVASCRIPT = true;
    static boolean UPLOAD_ARQUIVO = true;
    static boolean PODE_FAZER_UPLOAD = true;
    static boolean SOMENTE_CAMERA = false;
    static boolean MULTIPLOS_ARQUIVOS = false;
    static boolean PERMITIR_LOCALIZACAO = true;

    static boolean BARRA_DE_PROGRESSO = true;
    static boolean SUPORTAR_ZOOM = false;
    static boolean SALVAR_FORM_DATA = false;
    static boolean IS_OFFLINE = false;
    static boolean URL_EXTERNA = true;


    //private static String URL = "PAROQUIACASTELOFORTE.COM.BR"; //complete URL of your website or webpage
    private static String URL = "http://paroquiacasteloforte.com.br"; //complete URL of your website or webpage
   // private static String URL      = "https://github.com/mgks"; //complete URL of your website or webpage
    private static String TIPO = "*/*";  //to upload any file type using "*/*"; check file type references for more

    public static String HOST = buscarHost(URL);

    //Careful with these variable names if altering
    WebView webView;
    ProgressBar barraDeProgresso;
    //TextView mensagemDeCarregamento;
    NotificationManager gerenciadorDeNotificacao;
    Notification novaNotificacao;

    private String mensagemDaCamera;
    private ValueCallback<Uri> mensagemDoArquivo;
    private ValueCallback<Uri[]> caminhoDoArquivo;
    private final static int codigoDeRequisicaoDeArquivo = 1;

    private final static int permissaoLoc = 1;
    private final static int permissaoArquivo = 2;

    private SecureRandom aleatorio = new SecureRandom();

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimary));
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK) {
                if (requestCode == codigoDeRequisicaoDeArquivo) {
                    if (null == caminhoDoArquivo) {
                        return;
                    }
                    if (intent == null || intent.getData() == null) {
                        if (mensagemDaCamera != null) {
                            results = new Uri[]{Uri.parse(mensagemDaCamera)};
                        }
                    } else {
                        String dataString = intent.getDataString();
                        if (dataString != null) {
                            results = new Uri[]{ Uri.parse(dataString) };
                        } else {
                            if(MULTIPLOS_ARQUIVOS) {
                                if (intent.getClipData() != null) {
                                    final int numSelectedFiles = intent.getClipData().getItemCount();
                                    results = new Uri[numSelectedFiles];
                                    for (int i = 0; i < numSelectedFiles; i++) {
                                        results[i] = intent.getClipData().getItemAt(i).getUri();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            caminhoDoArquivo.onReceiveValue(results);
            caminhoDoArquivo = null;
        } else {
            if (requestCode == codigoDeRequisicaoDeArquivo) {
                if (null == mensagemDoArquivo) return;
                Uri result = intent == null || resultCode != RESULT_OK ? null : intent.getData();
                mensagemDoArquivo.onReceiveValue(result);
                mensagemDoArquivo = null;
            }
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.w("READ_PERM = ",Manifest.permission.READ_EXTERNAL_STORAGE);
        Log.w("WRITE_PERM = ",Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (!isTaskRoot()) {
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        if (BARRA_DE_PROGRESSO) {
            barraDeProgresso = findViewById(R.id.msw_progress);
        } else {
            findViewById(R.id.msw_progress).setVisibility(View.GONE);
        }
       // mensagemDeCarregamento = findViewById(R.id.msw_loading_text);


        get_info();


        if(PERMITIR_LOCALIZACAO && !verificarPermissao(1)){
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, permissaoLoc);
        }

        webView = findViewById(R.id.msw_view);


        WebSettings webSettings = webView.getSettings();

        if(!IS_OFFLINE){
            webSettings.setJavaScriptEnabled(PERMITIR_JAVASCRIPT);
        }
        webSettings.setSaveFormData(SALVAR_FORM_DATA);
        webSettings.setSupportZoom(SUPORTAR_ZOOM);
        webSettings.setGeolocationEnabled(PERMITIR_LOCALIZACAO);
        webSettings.setAllowFileAccess(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setDomStorageEnabled(true);

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {

                if(!verificarPermissao(2)){
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, permissaoArquivo);
                }else {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));

                    request.setMimeType(mimeType);
                    String cookies = CookieManager.getInstance().getCookie(url);
                    request.addRequestHeader("cookie", cookies);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setDescription(getString(R.string.dl_downloading));
                    request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                    request.allowScanningByMediaScanner();
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType));
                    DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    assert dm != null;
                    dm.enqueue(request);
                    Toast.makeText(getApplicationContext(), getString(R.string.dl_downloading2), Toast.LENGTH_LONG).show();
                }
            }
        });

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        } else if (Build.VERSION.SDK_INT >= 19) {
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }
        webView.setVerticalScrollBarEnabled(false);
        webView.setWebViewClient(new Callback());

        // carregando a url padrao
        abrirUrlNoWebView(URL, false);

        webView.setWebChromeClient(new WebChromeClient() {
            //Handling input[type="file"] requests for android API 16+
            /*
            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture){
                if(UPLOAD_ARQUIVO) {
                    mensagemDoArquivo = uploadMsg;
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(TIPO);
                    if(MULTIPLOS_ARQUIVOS) {
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(Intent.createChooser(i, getString(R.string.fl_chooser)), codigoDeRequisicaoDeArquivo);
                }
            }
            */
            //Handling input[type="file"] requests for android API 21+
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams){
                get_file();
                if(UPLOAD_ARQUIVO) {
                    if (caminhoDoArquivo != null) {
                        caminhoDoArquivo.onReceiveValue(null);
                    }
                    caminhoDoArquivo = filePathCallback;
                    Intent intencaoTirarFoto = null;
                    if (PODE_FAZER_UPLOAD) {
                        intencaoTirarFoto = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (intencaoTirarFoto.resolveActivity(MainActivity.this.getPackageManager()) != null) {
                            File foto = null;
                            try {
                                foto = create_image();
                                intencaoTirarFoto.putExtra("PhotoPath", mensagemDaCamera);
                            } catch (IOException ex) {
                                Log.e(TAG, "Criação falhou", ex);
                            }
                            if (foto != null) {
                                mensagemDaCamera = "file:" + foto.getAbsolutePath();
                                intencaoTirarFoto.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(foto));
                            } else {
                                intencaoTirarFoto = null;
                            }
                        }
                    }
                    Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
                    if(!SOMENTE_CAMERA) {
                        contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
                        contentSelectionIntent.setType(TIPO);
                        if (MULTIPLOS_ARQUIVOS) {
                            contentSelectionIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                        }
                    }
                    Intent[] intentArray;
                    if (intencaoTirarFoto != null) {
                        intentArray = new Intent[]{intencaoTirarFoto};
                    } else {
                        intentArray = new Intent[0];
                    }

                    Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                    chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
                    chooserIntent.putExtra(Intent.EXTRA_TITLE, getString(R.string.fl_chooser));
                    chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);
                    startActivityForResult(chooserIntent, codigoDeRequisicaoDeArquivo);
                }
                return true;
            }


            @Override
            public void onProgressChanged(WebView view, int progresso) {
                if (BARRA_DE_PROGRESSO) {
                    barraDeProgresso.setProgress(progresso);
                    if (progresso == 100) {
                        barraDeProgresso.setProgress(0);
                    }
                }
            }


            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if(Build.VERSION.SDK_INT < 23 || (Build.VERSION.SDK_INT >= 23 && verificarPermissao(1))){

                    callback.invoke(origin, true, false);
                } else {

                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, permissaoLoc);
                }
            }
        });
        if (getIntent().getData() != null) {
            String caminho     = getIntent().getDataString();

            abrirUrlNoWebView(caminho, false);
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        if (Build.VERSION.SDK_INT >= 23) {
            Bitmap bm = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
            ActivityManager.TaskDescription taskDesc;
            taskDesc = new ActivityManager.TaskDescription(getString(R.string.app_name), bm, getColor(R.color.colorPrimary));
            MainActivity.this.setTaskDescription(taskDesc);
        }
        //get_location();
    }


    private class Callback extends WebViewClient {
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            //get_location();
        }

        public void onPageFinished(WebView view, String url) {
            findViewById(R.id.msw_welcome).setVisibility(View.GONE);
            findViewById(R.id.msw_view).setVisibility(View.VISIBLE);
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            Toast.makeText(getApplicationContext(), getString(R.string.went_wrong), Toast.LENGTH_SHORT).show();
            abrirUrlNoWebView("file:///android_res/raw/error.html", false);
        }


        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return url_actions(view, url);
        }

        //Overriding webview URLs for API 23+ [suggested by github.com/JakePou]
        @TargetApi(Build.VERSION_CODES.N)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return url_actions(view, request.getUrl().toString());
        }
    }


    public String random_id() {
        return new BigInteger(130, aleatorio).toString(32);
    }

    //abrindo a url dentro do webview
    void abrirUrlNoWebView(String url, Boolean tab) {
        if (tab) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        } else {
            if(url.contains("?")){
                url += "&";
            } else {
                url += "?";
            }
            url += "rid="+random_id();
            webView.loadUrl(url);
        }
    }

    public boolean url_actions(WebView view, String url){
        boolean a = true;

        if (!IS_OFFLINE && !DetectaConexao.internetEstaDisponivel(MainActivity.this)) {
            Toast.makeText(getApplicationContext(), getString(R.string.check_connection), Toast.LENGTH_SHORT).show();


        } else if (url.startsWith("refresh:")) {
            abrirUrlNoWebView(URL, false);


        } else if (url.startsWith("tel:")) {
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
            startActivity(intent);


        } else if (url.startsWith("rate:")) {
            final String app_package = getPackageName();
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + app_package)));
            } catch (ActivityNotFoundException anfe) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + app_package)));
            }


        } else if (url.startsWith("share:")) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, view.getTitle());
            intent.putExtra(Intent.EXTRA_TEXT, view.getTitle()+"\nVisit: "+(Uri.parse(url).toString()).replace("share:",""));
            startActivity(Intent.createChooser(intent, getString(R.string.share_w_friends)));

        } else if (url.startsWith("exit:")) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else if (URL_EXTERNA && !buscarHost(url).equals(HOST)) {
            abrirUrlNoWebView(url,true);
        } else {
            a = false;
        }
        return a;
    }

    public static String buscarHost(String url){
        if (url == null || url.length() == 0) {
            return "";
        }
        int localizacaoDuasBarras = url.indexOf("//");
        if (localizacaoDuasBarras == -1) {
            localizacaoDuasBarras = 0;
        } else {
            localizacaoDuasBarras += 2;
        }
        int end = url.indexOf('/', localizacaoDuasBarras);
        end = end >= 0 ? end : url.length();
        int port = url.indexOf(':', localizacaoDuasBarras);
        end = (port > 0 && port < end) ? port : end;
        Log.w("URL Host: ",url.substring(localizacaoDuasBarras, end));
        return url.substring(localizacaoDuasBarras, end);
    }

    public void get_info(){
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setCookie(URL, "DEVICE=android");
        cookieManager.setCookie(URL, "DEV_API=" + Build.VERSION.SDK_INT);
    }

    public void get_file(){
        String[] perms = {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA};


        if (UPLOAD_ARQUIVO && PODE_FAZER_UPLOAD && !verificarPermissao(2) && !verificarPermissao(3)) {
            ActivityCompat.requestPermissions(MainActivity.this, perms, permissaoArquivo);


        } else if (UPLOAD_ARQUIVO && !verificarPermissao(2)) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, permissaoArquivo);


        } else if (PODE_FAZER_UPLOAD && !verificarPermissao(3)) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, permissaoArquivo);
        }
    }

    public boolean verificarPermissao(int permission){
        switch(permission){
            case 1:
                return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;

            case 2:
                return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;

            case 3:
                return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;

        }
        return false;
    }

    private File create_image() throws IOException {
        @SuppressLint("SimpleDateFormat")
        String file_name    = new SimpleDateFormat("yyyy_mm_ss").format(new Date());
        String new_name     = "file_"+file_name+"_";
        File sd_directory   = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(new_name, ".jpg", sd_directory);
    }

    // criando notificações customizadas com IDS
    public void mostrarNotificacao(int type, int id) {
        long when = System.currentTimeMillis();
        gerenciadorDeNotificacao = (NotificationManager) MainActivity.this.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent i = new Intent();
        if (type == 1) {
            i.setClass(MainActivity.this, MainActivity.class);
        } else if (type == 2) {
            i.setAction(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        } else {
            i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.addCategory(Intent.CATEGORY_DEFAULT);
            i.setData(Uri.parse("package:" + MainActivity.this.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
            i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        }
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(MainActivity.this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT);

        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, "");
        switch(type){
            case 1:
                builder.setTicker(getString(R.string.app_name));
                builder.setContentTitle(getString(R.string.loc_fail));
                builder.setContentText(getString(R.string.loc_fail_text));
                builder.setStyle(new NotificationCompat.BigTextStyle().bigText(getString(R.string.loc_fail_more)));
                builder.setVibrate(new long[]{350,350,350,350,350});
                builder.setSmallIcon(R.mipmap.ic_launcher);
                break;

            case 2:
                builder.setTicker(getString(R.string.app_name));
                builder.setContentTitle(getString(R.string.loc_perm));
                builder.setContentText(getString(R.string.loc_perm_text));
                builder.setStyle(new NotificationCompat.BigTextStyle().bigText(getString(R.string.loc_perm_more)));
                builder.setVibrate(new long[]{350, 700, 350, 700, 350});
                builder.setSound(alarmSound);
                builder.setSmallIcon(R.mipmap.ic_launcher);
                break;
        }
        builder.setOngoing(false);
        builder.setAutoCancel(true);
        builder.setContentIntent(pendingIntent);
        builder.setWhen(when);
        builder.setContentIntent(pendingIntent);
        novaNotificacao = builder.build();
        gerenciadorDeNotificacao.notify(id, novaNotificacao);
    }

    //ação disparada ao clicar no botão voltar do celular
    @Override
    public boolean onKeyDown(int keyCode, @NonNull KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        finish();
                    }
                    return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onConfigurationChanged(Configuration novaConfiguracao) {
        super.onConfigurationChanged(novaConfiguracao);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState ){
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
        webView.restoreState(savedInstanceState);
    }
}
