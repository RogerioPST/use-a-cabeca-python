package br.gov.caixa.setbot.setbot;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class Inicio extends Activity {

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicial);

		int PAGINA_INICIAL_TIME_OUT = 1000; // espera de um segundo
		new Handler().postDelayed(new Runnable() {

            /*
            Mostrando a tela inicial com o tempo definido na variavel PAGINA_INICIAL_TIME_OUT

             */

            @Override
            public void run() {
                // Este metodo será executado após terminado o time_out
                Intent intencaoAbrirIbc = new Intent(Inicio.this, IbcActivity.class);
                startActivity(intencaoAbrirIbc);

                // após chamar a activity do chatbot, fecha essa activity/tela
                finish();
            }
        }, PAGINA_INICIAL_TIME_OUT);
    }

}
