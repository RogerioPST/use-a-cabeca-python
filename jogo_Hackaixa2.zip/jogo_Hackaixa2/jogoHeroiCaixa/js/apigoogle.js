
/* apigoogle.js */

var image = 'img/trophyx.png';

var latitudeObjetivo = -15.7997;
var longitudeObjetivo = -47.8642;


// valores mais facilmente atingiveis para saber que funcionou
//var latitudeObjetivo = -15.8151;
//var longitudeObjetivo = -47.8695;


var latitudeInicial = -15.8191;
var longitudeInicial = -47.8781;

var styles = [
  {
"elementType": "geometry",
    "stylers": [
      { "hue": "#ffa200" },
      { "invert_lightness": true },
      { "lightness": 50 },
      { "saturation": 35 },
      { "gamma": 1.31 }
    ]
  },{
    "elementType": "labels",
    "stylers": [
      { "hue": "#ffa200" }
    ]
  },{
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      { "color": "#8F9B98" }
    ]
  },{
    "elementType": "labels.text.fill",
    "stylers": [
      { "color": "#f8ead0" }
    ]
  },{
    "elementType": "labels.text.stroke",
    "stylers": [
      { "color": "#6a5035" }
    ]
  },{
    "featureType": "landscape.natural",
    "elementType": "geometry",
    "stylers": [
      { "color": "#9c9743" }
    ]
  },{
    "featureType": "landscape.man_made",
    "elementType": "geometry",
    "stylers": [
      { "color": "#9f8053" }
    ]
  },{
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [
      { "color": "#ACA74C" }
    ]
  },{
    "featureType": "road",
    "elementType": "geometry.fill",
    "stylers": [
      { "color": "#d3b681" }
    ]
  },{
    "featureType": "road",
    "elementType": "geometry.stroke",
    "stylers": [
      { "color": "#644F34" }
    ]
  },{
    "featureType": "road.arterial",
    "elementType": "geometry.fill",
    "stylers": [
      { "color": "#c6a15e" }
    ]
  },{
    "featureType": "road.local",
    "elementType": "geometry.fill",
    "stylers": [
      { "color": "#b09061" }
    ]
  },{
    "featureType": "transit.line",
    "elementType": "geometry",
    "stylers": [
      { "color": "#876b48" }
    ]
  },{
    "featureType": "transit.station",
    "elementType": "geometry",
    "stylers": [
      { "color": "#a58557" }
    ]
  }
];


function initialize(){

 var latlngInicio= new google.maps.LatLng(latitudeInicial, longitudeInicial);

var mapas;
mapas = new google.maps.Map(document.getElementById('map'),{
	center:{
		lat:latitudeObjetivo, 
		lng:longitudeObjetivo
	},
	zoom: 13
});

var styledMap = new google.maps.StyledMapType( styles, {name: "Styled Map"} );
mapas.mapTypes.set('map_style', styledMap);
mapas.setMapTypeId('map_style');

//marker
marker = new google.maps.Marker({
	position:{
		lat: latitudeInicial, 
		lng: longitudeInicial
	},
	map: mapas
});




var markerObjetivo = new google.maps.Marker({
	position:{
		lat: latitudeObjetivo,
		lng: longitudeObjetivo
	},
	map: mapas, 
	title: "Objetivo",
	icon: image
});



var latlngObjetivo= new google.maps.LatLng(latitudeObjetivo,  longitudeObjetivo);

 marker.setPosition(latlngInicio);
 markerObjetivo.setPosition(latlngObjetivo);

 return marker;

}


/*
var map;
var marker;

function initialize() {
    var myLatlng = new google.maps.LatLng(40.65, -74);
    var myOptions = {
        zoom: 2,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
    }

    map = new google.maps.Map(document.getElementById('map'), myOptions);
    atualizarLocal(40.65,-74);
}



function atualizarLocal(lat, lng){

	var newLatLng = new google.maps.LatLng(lat, lng);
    marker.setPosition(newLatLng);
}






// Onload handler to fire off the app.
google.maps.event.addDomListener(window, 'load', initialize);

*/


  /*
  ['Third Shoppe', -37.816935, 144.966877],
  ['Fourth Shoppe', -37.818714, 145.036494],
  ['Fifth Shoppe', -37.793834, 144.987018],
  ['Sixth Shoppe', -37.737116, 144.998581],
  ['Seventh Shoppe', -37.765528, 144.922624]
  */
/*
    var map;
  var centerPos = new google.maps.LatLng(-37.8046274,144.972156);
  var zoomLevel = 11;
function atualizaMarca(){
	   var newLatLng = new google.maps.LatLng(lat, lng);
    marker.setPosition(newLatLng);

}

  function atualizarLocal(latitude, longitude){
var localizacoes = [
  ['First Shoppe', -latitude, longitude],
  ['Second Shoppe', -37.675648, 145.026125]

];
return localizacoes;
}
  
  function initialize() {
var mapOptions = {
      center: centerPos,
      zoom: zoomLevel
    };
    map = new google.maps.Map( document.getElementById("map"), mapOptions );
    
 
for (i = 0; i < locations.length; i++) {  
  marker = new google.maps.Marker({
position: new google.maps.LatLng(locations[i][1], locations[i][2]),
    title: locations[i][0],
    map: map
  });
}
  }
  */
  //google.maps.event.addDomListener(window, 'load', initialize);
