// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  dialogFlow: {
    caixaBot: 'eab8fdb011a2406bb7f9c5a255a9869f',
  },
  api: 'https://internetbanking.caixa.gov.br',
  api_SSO:'https://logindes.caixa.gov.br',
  api_Servicos: 'https://api.caixa.gov.br:8443'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
