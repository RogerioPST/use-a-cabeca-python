import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { ResponseSSO, ServicoSocial } from './chat/chat.model';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  private API_URL_PREFIX = `${environment.api}/sinbc/nb/adesaoCorrentista`;
  private API_IDENT_POSITIVA_FRACA = `${
    this.API_URL_PREFIX
  }/confirmarIdentificacaoPositivaFraca`;
  private API_CONFIR_IDENT_POS_FORTE = `${
    this.API_URL_PREFIX
  }/confirmarIdentificacaoPositivaForte`;
  private API_ADESAO_USUARIO_NOVO = `${
    this.API_URL_PREFIX
  }/adesaoCadastrarUsuarioNovo`;
  private API_ADESAO_USUARIO_RESUMO2 = `${
    this.API_URL_PREFIX
  }/adesaoCadastrarUsuarioResumo2`;
  private API_ADESAO_USUARIO_EFETIVA = `${
    this.API_URL_PREFIX
  }/adesaoCadastrarUsuarioEfetiva`;

  private API_SSO_TOKEN = `${environment.api_SSO}/auth/realms/internet/protocol/openid-connect/token`;
  private API_SERVICOS_SOCIAIS = `${environment.api_Servicos}/sandbox/servicos-sociais/v1/consulta`;

  constructor(private http: HttpClient) {}

  confirmarIdentificacaoPositivaFraca(usuario) {
    return this.http
      .post(
        this.API_IDENT_POSITIVA_FRACA,
        new HttpParams({
          fromObject: {
            cpf: usuario.cpf,
            nome: usuario.nome,
            dataNascimento: usuario.dataNascimento,
            userAgent: navigator.userAgent,
            pluginGBusterVersion: '',
            isTablet: 'false',
            isPluginGBusterInstallation: 'false',
            warsawInstalled: 'false'
          }
        }),
        {
          withCredentials: true,
          observe: 'response',
          responseType: 'text'
        }
      )
      .pipe(
        map(res => {
          if (res.body.includes('Cadastro de usuário com conta')) {
            return;
          }
          throw new Error('Falha no request de identificação positiva fraca');
        })
      );
  }

  confirmarIdentificacaoPositivaForte(usuario) {
    console.log(usuario);
    return this.http
      .post(
        this.API_CONFIR_IDENT_POS_FORTE,
        new HttpParams({
          fromObject: {
            tipoContaDestino: usuario.tipoContaDestino,
            agencia: usuario.agencia,
            conta: `00000000${usuario.conta}`.slice(-8),
            digito: usuario.digito,
            senha: usuario.senha
          }
        }),
        {
          withCredentials: true,
          observe: 'response',
          responseType: 'text'
        }
      )
      .pipe(
        map(res => {
          if (res.body.includes('Cadastro de usuário com conta')) {
            return;
          }
          throw new Error('Falha no request de identificação positiva forte');
        })
      );
  }

  adesaoCadastrarUsuarioNovo(usuario) {
    return this.http
      .post(
        this.API_ADESAO_USUARIO_NOVO,
        new HttpParams({
          fromObject: {
            usuario: usuario.name.replace(/\./g, '').replace('-', ''),
            senha: usuario.passKeyboard,
            confirmaSenha: usuario.passKeyboardConfirm,
            pluginGBusterVersion: '',
            isTablet: 'false',
            isPluginGBusterInstallation: 'false',
            warsawInstalled: 'false'
          }
        }),
        {
          withCredentials: true,
          observe: 'response',
          responseType: 'text'
        }
      )
      .pipe(
        map(res => {
          if (res.body.includes('Cadastro de usuário com conta')) {
            return;
          }
          throw new Error('Falha no request de adesao no cadastro');
        })
      );
  }

  adesaoCadastrarUsuarioResumo2() {
    return this.http
      .post(this.API_ADESAO_USUARIO_RESUMO2, 'tipoPessoa=7', {
        withCredentials: true,
        observe: 'response',
        responseType: 'text'
      })
      .pipe(
        map(res => {
          if (res.body.includes('Cadastro de usuário com conta')) {
            return;
          }
          throw new Error('Falha no request de adesao no cadastro resumo2');
        })
      );
  }

  adesaoCadastrarUsuarioEfetiva() {
    return this.http
      .post(this.API_ADESAO_USUARIO_EFETIVA, '', {
        withCredentials: true,
        observe: 'response',
        responseType: 'text'
      })
      .pipe(
        map(res => {
          if (res.body.includes('Cadastro de usuário com conta')) {
            return;
          }
          throw new Error('Falha no request de efetivar adesao');
        })
      );
  }
  buscarTokenNoSSO() {
    return this.http
    .post<ResponseSSO>(
      this.API_SSO_TOKEN,
    new HttpParams({
      fromObject: {
        grant_type: 'password',
        client_id: 'cli-web-hackcaixa',
        client_secret: 'd677675f-4b68-4561-8d75-4f139caa6cf7',
        username: '12312312388',
        password: '718293'
      }
    }),
      {
        withCredentials: true,
      }
    )
    .pipe(
      map(res => {
      return res.refresh_token;

      })
    );
  }

  consultarServicosSociais(token: string, nis: string ) {

    return this.http
    .get<ServicoSocial>(
      `${this.API_SERVICOS_SOCIAIS}?NIS=${nis}`, {
        headers: {
          Accept: 'application/json',
          apikey: 'l7xx3e4479b454a04307acc6ee5e1258f9e6',
          Authorization: `bearer ${token}`
        }
      })
      .pipe(
        map(res => {
          return res;
        })
      );
    }
}
