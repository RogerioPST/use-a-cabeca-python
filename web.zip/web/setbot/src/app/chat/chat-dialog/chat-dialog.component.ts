import { Component, OnInit, NgZone, ChangeDetectorRef } from '@angular/core';
import { ChatService } from '../chat.service';
import { Observable } from 'rxjs';
import { Msg } from '../chat.model';
import { scan } from 'rxjs/operators';

@Component({
  selector: 'chat-dialog',
  templateUrl: './chat-dialog.component.html',
  styleUrls: ['./chat-dialog.component.scss']
})
export class ChatDialogComponent implements OnInit {

  messages: Observable<Msg[]>;
  formValue: string;
  inputName: string;

  constructor(private chat: ChatService, private zone: NgZone, private chageDetector: ChangeDetectorRef) {
    this.chat.inputName.subscribe(inputName => {
      this.inputName = inputName;
    });
   }

  ngOnInit() {
    // appends to array after each new message is added to feedSource
    this.messages = this.chat.conversation.asObservable().pipe(scan((acc, val) => acc.concat(val)));
  }

  sendMessage() {
    this.chat.converse(this.formValue);
    this.formValue = '';
  }

  upperCase($event) {
    this.formValue = $event.target.value.toLocaleUpperCase();
  }

  validaDoisNomes($event) {
    const regexp = /[a-zA-Z]+\s+[a-zA-Z]+/g;
    if (!regexp.test($event.target.value)) {
      this.chat.update(new Msg('O nome completo deve conter ao menos 2 nomes.', 'error'));
      this.chageDetector.detectChanges();
    } else {
      this.sendMessage();
    }
  }

  formatCPF($event) {
    this.formValue = $event.target.value.replace(/\d{3}(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  }

  validaCPF($event) {
    if (this.validarCpf($event.target.value)) {
      this.chat.update(new Msg('CPF inválido.', 'error'));
    }
  }

  validarCpf(valor: string): boolean {
    const val = valor.replace(/[^0-9]/g, '');
    const digitos = val.substr(0, 9);

    // Faz o cálculo dos 9 primeiros dígitos do CPF para obter o primeiro dígito
    // Faz o cálculo dos 10 dígitos do CPF para obter o último dígito
    let cpf = this.calcDigitosPosicoes(digitos);
    cpf = this.calcDigitosPosicoes(cpf, 11);

    return cpf === val;
  }

  calcDigitosPosicoes(digitos: string, posicoes: number = 10): string {
    let soma = 0;
    let posicao: number = posicoes;
    // Faz a soma dos dígitos com a posição
    // Ex. para 10 posições:
    //   0    2    5    4    6    2    8    8   4
    // x10   x9   x8   x7   x6   x5   x4   x3  x2
    //   0 + 18 + 40 + 28 + 36 + 10 + 32 + 24 + 8 = 196
    for (let i = 0; i < digitos.length; i += 1) {
      // Preenche a soma com o dígito vezes a posição
      soma = soma + parseInt(digitos[i], 10) * posicao;
      posicao -= 1;

      // Parte específica para CNPJ
      // Ex.: 5-4-3-2-9-8-7-6-5-4-3-2
      if (posicao < 2) {
        posicao = 9;
      }
    }

    soma = soma % 11;

    if (soma < 2) {
      soma = 0;
    } else {
      // Se for maior que 2, o resultado é 11 menos soma_digitos
      // Ex.: 11 - 9 = 2
      // Nosso dígito procurado é 2
      soma = 11 - soma;
    }

    // Concatena mais um dígito aos primeiro nove dígitos
    return digitos + soma;
  }

  maskData($event) {
    let newVal = $event.target.value.replace(/\D/g, '');
    if (newVal.length === 0) {
      newVal = '';
    } else if (newVal.length <= 10) {
      newVal = newVal.replace(/(\d{2})(\d)/, '$1/$2');
      newVal = newVal.replace(/(\d{2})(\d)/, '$1/$2');
      newVal = newVal.replace(/(\d{4})(\d{1,2})$/, '$1/$2');
    }
    this.formValue = newVal;
  }

  maskCampoConta($event, qtd0: number) {
    this.formValue =  this.padLeft($event.target.value.conta, qtd0);
  }

  padLeft(valor, qtd0) {
    const campo = valor.trim();
    if (campo.length) {
      return campo.padStart(qtd0, 0);
    }
    return '';
  }
}
