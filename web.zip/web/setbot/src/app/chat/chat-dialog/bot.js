function toBottom()
{
    window.scrollTo(0, document.body.scrollHeight);
}