import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

import { ApiAiClient } from 'api-ai-javascript/es6/ApiAiClient';
import { BehaviorSubject } from 'rxjs';
import { ChatDialog, Msg, ServicoSocial } from './chat.model';
import { AppService } from '../app.service';

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  readonly token = environment.dialogFlow.caixaBot;
  readonly client = new ApiAiClient({ accessToken: this.token });

  private nis: any;
  conversation = new BehaviorSubject<Msg[]>([]);
  inputName = new BehaviorSubject<string>('normal');

  beneficioSocial: ServicoSocial;

  constructor(private appService: AppService) {
  }

  updateInputName(name: string) {
    this.inputName.next(name);
  }

  //  Adds message to source
  update(msg: Msg) {
    this.conversation.next([msg]);
  }

  // Sends and receives messages via DialogFlow
  converse(msg: string) {
    const userMessage = new Msg(msg, 'user');
    this.update(userMessage);
    let usuario;

    return this.client.textRequest(msg).then((res: ChatDialog) => {
      const speech = res.result.fulfillment.speech;
      console.log("speech"+speech);
      if (speech.includes('nome')) {
        this.updateInputName('nome');
      }
      if (speech.includes('CPF')) {
        this.updateInputName('cpf');
      }
      if (speech.includes('data')) {
        this.updateInputName('data');
      }
      if (speech.includes('agencia')) {
        this.updateInputName('agencia');
      }
      if (speech.includes('operacao')) {
        this.updateInputName('operacao');
      }
      if (speech.includes('conta')) {
        this.updateInputName('conta');
      }
      if (speech.includes('dv')) {
        this.updateInputName('dv');
      }
      if (speech.includes('senhaCartao')) {
        this.updateInputName('senhaCartao');
      }
      if (speech.includes('senhaInternet')) {
        this.updateInputName('senhaInternet');
      }
      if (speech.includes('confirmaSenhaInternet')) {
        this.updateInputName('confirmaSenhaInternet');
      }

      if (res.result.action === 'dados-pessoais') {
        usuario = {
          cpf: res.result.parameters.cpf,
          nome: res.result.parameters.name,
          dataNascimento: res.result.parameters.dtNascimento
            ? this.getFormattedDate(res.result.parameters.dtNascimento)
            : ''
        };
        if (!this.isEmpty(usuario)) {
          this.appService
            .confirmarIdentificacaoPositivaFraca(usuario)
            .subscribe(
              callResponse => {
                this.update(
                  new Msg(speech, 'bot')
                );
              },
              error => {
                this.update(new Msg(error, 'bot'));
              }
            );
          return;
        }
      }

      if (res.result.action === 'dados-conta') {
        usuario = {
          tipoContaDestino: res.result.parameters.tipoContaDestino,
          agencia: res.result.parameters.agencia,
          conta: res.result.parameters.conta,
          digito: res.result.parameters.digito,
          senha: res.result.parameters.senha
        };
        if (!this.isEmpty(usuario)) {
          this.appService
            .confirmarIdentificacaoPositivaForte(usuario)
            .subscribe(
              callResponse => {
                this.update(
                  new Msg(speech, 'bot')
                );
              },
              error => {
                this.update(new Msg(error, 'bot'));
              }
            );
          return;
        }
      }

      if (res.result.action === 'dados-senha') {
        usuario = {
          usuario: res.result.parameters.usuario,
          passKeyboard: res.result.parameters.passKeyboard,
          passKeyboardConfirm: res.result.parameters.passKeyboardConfirm
        };
        if (!this.isEmpty(usuario)) {
          this.appService.adesaoCadastrarUsuarioNovo(usuario).subscribe(
            callResponse => {
              this.appService
                .adesaoCadastrarUsuarioResumo2()
                .subscribe(resumo2 => {
                  this.appService
                    .adesaoCadastrarUsuarioEfetiva()
                    .subscribe(efetiva => {
                      this.update(
                        new Msg(speech, 'bot')
                      );
                    });
                });
            },
            error => {
              this.update(new Msg(error, 'bot'));
            }
          );
          return;
        }
      }

      if (res.result.action === 'consulta-nis-seguro-desemprego') {
        if (res.result.parameters.nis !== '') {

          this.appService.buscarTokenNoSSO().subscribe(tok => {
            this.appService.consultarServicosSociais(tok, res.result.parameters.nis).subscribe(serv => {
              this.beneficioSocial = serv;

              if (this.beneficioSocial.dados_consulta_servicos_sociais.dados_seguro_desemprego) {
                const mensag = 'Você possui '
                  + this.beneficioSocial.dados_consulta_servicos_sociais.dados_seguro_desemprego
                    .beneficios.beneficio.length + ' parcela(s) do seguro desemprego cada uma no valor de R$'
                  + this.beneficioSocial.dados_consulta_servicos_sociais
                    .dados_seguro_desemprego.beneficios.beneficio[0].parcela.valor.replace('.', ',')
                  + '. A primeira parcela estará disponível no dia ' +
                  this.beneficioSocial.dados_consulta_servicos_sociais.dados_seguro_desemprego.beneficios
                    .beneficio[0].data_valida_inicio;
                this.update(new Msg(mensag, 'bot'));
              } else {
                this.update(new Msg('Infelizmente você NÃO possui.', 'bot'));
              }
            });
          });
        }
      }
      if (res.result.action === 'consulta-nis-pis') {
        if (res.result.parameters.nis !== '') {

          this.appService.buscarTokenNoSSO().subscribe(tok => {
            this.appService.consultarServicosSociais(tok, res.result.parameters.nis).subscribe(serv => {
              this.beneficioSocial = serv;
              console.log(serv);
              if (this.beneficioSocial.dados_consulta_servicos_sociais.dados_fgts) {

                console.log( 'aqui' + this.beneficioSocial.dados_consulta_servicos_sociais.dados_fgts);
                this.update(new Msg('Você possui!!', 'bot'));
              } else {
                this.update(new Msg('Infelizmente você NÃO possui.', 'bot'));
              }

            });
          });
        }
      }

      if (res.result.action === 'busca-fgts-liberado') {
        if (res.result.parameters.nis !== '') {

          this.appService.buscarTokenNoSSO().subscribe(tok => {
            this.appService.consultarServicosSociais(tok, res.result.parameters.nis).subscribe(serv => {
              this.beneficioSocial = serv;

              this.beneficioSocial.dados_consulta_servicos_sociais.dados_fgts.beneficios.beneficio.forEach( cadaBeneficioFGTS => {
                if (cadaBeneficioFGTS.situacao == "LIBERADO" && cadaBeneficioFGTS.situacao_cvc == "DISPONIVEL"){ 
                  let mensagemResposta = cadaBeneficioFGTS.valor + " R$ " + " da empresa " + cadaBeneficioFGTS.empresa; 
                  this.update(new Msg(mensagemResposta, 'bot'));
                }
                else{
                  this.update(new Msg("Não tem valor disponível para sacar", 'bot'));
                }
              });
            });
          });
        }
      }

      if (res.result.action === 'busca-fgts-sacado') {
        if (res.result.parameters.nis !== '') {

          this.appService.buscarTokenNoSSO().subscribe(tok => {
            this.appService.consultarServicosSociais(tok, res.result.parameters.nis).subscribe(serv => {
              this.beneficioSocial = serv;

              this.beneficioSocial.dados_consulta_servicos_sociais.dados_fgts.beneficios.beneficio.forEach( cadaBeneficioFGTS => {
                if (cadaBeneficioFGTS.situacao == "PAGO" && cadaBeneficioFGTS.situacao_cvc == "PAGO"){ 
                  let mensagemResposta = cadaBeneficioFGTS.valor + " R$ " + " da empresa " + cadaBeneficioFGTS.empresa; 
                  this.update(new Msg(mensagemResposta, 'bot'));
                }
                else{
                  this.update(new Msg("Você ainda não sacou. Pode ser que você tenha algum valor", 'bot'));
                }
              });
            });
          });
        }
      }       

       

      if (res.result.action === 'onde-sacar') {       
            this.update(new Msg("Você pode sacar na lotérica. Basta clicar no link abaixo <br />google maps", 'bot'));      
      }  

      const botMessage = new Msg(speech, 'bot');
      this.update(botMessage);
    });
  }

  isEmpty(obj) {
    for (const key in obj) {
      if (obj[key] === '') {
        return true;
      }
    }
    return false;
  }

  getFormattedDate(date) {
    const data = new Date(date);
    const year = data.getFullYear();

    let month = (1 + data.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;

    let day = (1 + data.getDate()).toString();
    day = day.length > 1 ? day : '0' + day;

    return day + '/' + month + '/' + year;
  }

  consultarServicosSocial(nis: any) {

    this.appService.buscarTokenNoSSO().subscribe(res => {
      this.appService.consultarServicosSociais(res, nis).subscribe(serv => {
        this.beneficioSocial = serv;
        console.log('não!' + this.beneficioSocial);
      });
    });
  }
}
