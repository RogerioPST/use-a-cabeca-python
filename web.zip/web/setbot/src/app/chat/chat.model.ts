export class Msg {
  constructor(public content: string, public sentBy: string) {}
}

export interface Parameters {
    name?: string;
    cpf?: string;
    dtNascimento?: string;
    tipoContaDestino?: string;
    agencia?: string;
    conta?: string;
    digito?: string;
    senha?: string;
    usuario?: string;
    passKeyboard?: string;
    passKeyboardConfirm?: string;
    nis?: any;
}

export interface Metadata {
  intentId: string;
  webhookUsed: string;
  webhookForSlotFillingUsed: string;
  isFallbackIntent: string;
  intentName: string;
}

export interface Message {
  type: number;
  speech: string;
}

export interface Fulfillment {
  speech: string;
  messages: Message[];
}

export interface Result {
  source: string;
  resolvedQuery: string;
  action: string;
  actionIncomplete: boolean;
  parameters: Parameters;
  contexts: any[];
  metadata: Metadata;
  fulfillment: Fulfillment;
  score: number;
}

export interface Status {
  code: number;
  errorType: string;
}

export interface ChatDialog {
  id: string;
  timestamp: Date;
  lang: string;
  result: Result;
  status: Status;
  sessionId: string;
}
export interface ResponseSSO {
  access_token: string;
  expires_in: number;
  refresh_expires_in: number;
  refresh_token: string;
  token_type: string;
  'not-before-policy': number;
  session_state: string;
}
export interface ServicoSocial {
  dados_consulta_servicos_sociais: Dadosconsultaservicossociais;
}

export interface Dadosconsultaservicossociais {
  dados_fgts: Dadosfgts;
  dados_seguro_desemprego: Dadossegurodesemprego;
}

export interface Dadossegurodesemprego {
  beneficios: Beneficios2;
}

export interface Beneficios2 {
  beneficio: Beneficio2[];
}

export interface Beneficio2 {
  parcela: Parcela;
  situacao_cvc: string;
  data_valida_inicio: string;
  data_valida_fim: string;
}

export interface Parcela {
  numero: string;
  situacao: string;
  valor: string;
}

export interface Dadosfgts {
  beneficios: Beneficios;
}

export interface Beneficios {
  beneficio: Beneficio[];
}

export interface Beneficio {
  situacao: string;
  situacao_cvc: string;
  empresa: string;
  valor: string;
  data_prevista: string;
  agencia_prevista: string;
}